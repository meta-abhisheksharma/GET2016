package Menu_Submenu;

public class SubMenu {
		String subMenuName;
		
	public SubMenu(String name){
		subMenuName= name;	
	}
		
	public String getSubMenuName(){
		return subMenuName;
	}

}
